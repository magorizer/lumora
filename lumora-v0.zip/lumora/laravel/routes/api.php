<?php

use App\Http\Controllers\Api\ActionController;
use App\Http\Controllers\Api\CheckinController;
use App\Http\Controllers\Api\ClerkWebhookController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\GoalController;
use App\Http\Controllers\Api\LifeAreaController;
use App\Http\Controllers\Api\MemoryController;
use App\Http\Controllers\Api\OnboardingController;
use App\Http\Controllers\Api\PatternController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\WeeklyReviewController;
use App\Http\Middleware\ClerkAuth;
use Illuminate\Support\Facades\Route;

Route::middleware(ClerkAuth::class)->group(function (): void {
    Route::get('/users/profile', [UserController::class, 'profile']);
    Route::put('/users/profile', [UserController::class, 'updateProfile']);

    Route::get('/life-areas', [LifeAreaController::class, 'index']);
    Route::get('/onboarding', [OnboardingController::class, 'show']);
    Route::post('/onboarding', [OnboardingController::class, 'store']);
    Route::get('/dashboard', [DashboardController::class, 'show']);

    Route::apiResource('goals', GoalController::class)->except(['show']);
    Route::apiResource('checkins', CheckinController::class)->except(['show']);
    Route::apiResource('memories', MemoryController::class)->except(['show']);
    Route::apiResource('actions', ActionController::class)->except(['show']);

    Route::get('/patterns', [PatternController::class, 'index']);
    Route::put('/patterns/{pattern}/feedback', [PatternController::class, 'feedback']);

    Route::get('/weekly-reviews/current', [WeeklyReviewController::class, 'current']);
    Route::get('/weekly-reviews', [WeeklyReviewController::class, 'index']);
    Route::put('/weekly-reviews/{review}', [WeeklyReviewController::class, 'update']);
});

Route::post('/clerk/webhook', [ClerkWebhookController::class, 'handle']);
