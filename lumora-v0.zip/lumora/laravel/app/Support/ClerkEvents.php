<?php

namespace App\Support;

final class ClerkEvents
{
    public const CREATED = 'user.created';

    public const UPDATED = 'user.updated';

    public const DELETED = 'user.deleted';
}
