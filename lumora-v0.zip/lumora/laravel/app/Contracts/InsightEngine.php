<?php

namespace App\Contracts;

use App\Models\User;
use Carbon\CarbonImmutable;
use Illuminate\Support\Collection;

interface InsightEngine
{
    /** @return Collection<int, array<string, mixed>> */
    public function detect(User $user, CarbonImmutable $from, CarbonImmutable $to): Collection;
}
