<?php

namespace App\Providers;

use App\Contracts\InsightEngine;
use App\Services\RuleBasedInsightEngine;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(InsightEngine::class, RuleBasedInsightEngine::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        //
    }
}
