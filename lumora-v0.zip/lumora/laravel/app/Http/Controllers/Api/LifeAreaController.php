<?php

namespace App\Http\Controllers\Api;

use App\Models\LifeArea;
use Illuminate\Http\JsonResponse;

class LifeAreaController
{
    public function index(): JsonResponse
    {
        return response()->json(LifeArea::query()->orderBy('sort_order')->get(['id', 'slug', 'name', 'icon']));
    }
}
